"""Global config for PMO Enterprise Tool.

The active data-source path is stored in `data/source.json` so the app
remembers the user's chosen Excel file across reruns. The path may point to
a local file OR to a OneDrive/SharePoint-synced folder on the same machine.
"""
from pathlib import Path
import json

BASE_DIR   = Path(__file__).parent
DATA_DIR   = BASE_DIR / "data"
ASSETS_DIR = BASE_DIR / "assets"
EXPORT_DIR = BASE_DIR / "exports"
UPLOAD_DIR = DATA_DIR / "uploads"
for d in (DATA_DIR, EXPORT_DIR, UPLOAD_DIR):
    d.mkdir(parents=True, exist_ok=True)

DEFAULT_MASTER_FILE = DATA_DIR / "PMO_Master.xlsx"
SETTINGS_FILE       = DATA_DIR / "source.json"


def get_master_file() -> Path:
    """Return the currently-active master Excel file (persisted)."""
    if SETTINGS_FILE.exists():
        try:
            p = Path(json.loads(SETTINGS_FILE.read_text()).get("path", ""))
            if p.exists():
                return p
        except Exception:
            pass
    return DEFAULT_MASTER_FILE


def set_master_file(path: str | Path) -> Path:
    """Persist a new master path. Returns the resolved Path."""
    p = Path(path).expanduser().resolve()
    SETTINGS_FILE.write_text(json.dumps({"path": str(p)}))
    return p


# Back-compat for any module still importing MASTER_FILE
MASTER_FILE = get_master_file()

SHEETS = {
    "projects":     "Projects",
    "roadmap":      "Roadmap",
    "risks":        "Risks",
    "governance":   "Governance",
    "financials":   "Financials",
    "resources":    "Resources",
    "dependencies": "Dependencies",
    "pipeline":     "Pipeline",
    "costbenefit":  "CostBenefit",
}

RAG_COLORS = {"Green": "#22c55e", "Amber": "#f59e0b", "Red": "#ef4444"}
THEME_COLORS = ["#3b82f6", "#8b5cf6", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4"]

STAGES = ["Idea", "Discovery", "Business Case", "Funding",
          "Design", "Build", "Test", "Deploy", "Benefits Realisation"]
