"""Generate data/PMO_Master.xlsx with realistic sample PMO data.

Run once before launching the app:
    python generate_master.py
"""
from pathlib import Path
import random
import pandas as pd
import numpy as np

random.seed(42); np.random.seed(42)
OUT = Path(__file__).parent / "data" / "PMO_Master.xlsx"
OUT.parent.mkdir(parents=True, exist_ok=True)

PROGRAMS  = ["Digital Transformation","Cyber Security","Cloud Migration","Data & AI","Customer Experience"]
THEMES    = ["Infrastructure","Digital & Applications","Data & Analytics","Cyber Security","Business Transformation"]
SPONSORS  = ["CIO","CFO","COO","CMO","CTO"]
PMS       = ["John Smith","Jane Doe","Mike Johnson","Sarah Lee","Alex Brown","Priya Patel","Carlos Diaz"]
STATUSES  = ["Active","Active","Active","Completed","Pipeline"]
RAGS      = ["Green","Green","Green","Amber","Amber","Red"]
PRIORITY  = ["P1 - Critical","P2 - High","P3 - Medium","P4 - Low"]
INVEST    = ["Run","Grow","Transform"]
STAGES    = ["Idea","Discovery","Business Case","Funding","Design","Build","Test","Deploy","Benefits Realisation"]
SKILLS    = ["PM","BA","Dev","QA","DevOps","Data","Security","UX","Architect"]

PROJECT_NAMES = [
    "Customer Portal","Cloud Migration","Data Platform","AI Assistant","Network Refresh",
    "Cyber Security Program","CRM Upgrade","Mobile App","ERP Modernisation","Workforce Enablement",
    "IoT Initiative","Analytics Platform","API Gateway","Identity Mgmt","Service Desk",
    "Infrastructure Upg","App Modernisation","RPA Program","Vendor Mgmt","Process Automation",
    "Data Warehouse","DevOps Tools","Workforce Portal","Process Mining","Customer Insights",
    "ERP Modernisation 2","Cyber Program","Mobile App 2","Analytics Platform 2","Service Desk 2",
    "Quality Mgmt","Compliance Hub","Risk Platform","Treasury Sys","Payroll Cloud",
    "HR Self-Service","SAP S/4HANA","Salesforce CRM","M365 Rollout","Zero-Trust Net",
]

projects = []
for i, name in enumerate(PROJECT_NAMES, start=1):
    budget   = round(random.uniform(0.2, 2.5) * 1_000_000, 0)
    actual   = round(budget * random.uniform(0.2, 1.05), 0)
    forecast = round(budget * random.uniform(0.8, 1.2), 0)
    start = pd.Timestamp("2025-01-01") + pd.Timedelta(days=random.randint(0, 365))
    end   = start + pd.Timedelta(days=random.randint(90, 600))
    projects.append({
        "Project ID":  f"PRJ{i:03d}",
        "Project Name": name,
        "Program":     random.choice(PROGRAMS),
        "Theme":       random.choice(THEMES),
        "Sponsor":     random.choice(SPONSORS),
        "PM":          random.choice(PMS),
        "Priority":    random.choice(PRIORITY),
        "Investment Type": random.choice(INVEST),
        "Start Date":  start,
        "End Date":    end,
        "Budget":      budget,
        "Actual Cost": actual,
        "Forecast":    forecast,
        "Status":      random.choice(STATUSES),
        "RAG":         random.choice(RAGS),
    })
df_projects = pd.DataFrame(projects)

# Roadmap monthly phase rows
roadmap_rows = []
phases = ["Discovery","Design","Build","Test","Deploy"]
for p in projects:
    months = pd.date_range(p["Start Date"], p["End Date"], freq="MS")
    for m in months:
        roadmap_rows.append({"Project ID": p["Project ID"], "Month": m.strftime("%b"),
                             "Year": m.year, "Phase": random.choice(phases),
                             "Status": p["Status"]})
df_roadmap = pd.DataFrame(roadmap_rows)

# Risks
risks = []
for r in range(1, 61):
    risks.append({
        "Risk ID":     f"R{r:03d}",
        "Project ID":  random.choice(df_projects["Project ID"].tolist()),
        "Description": random.choice([
            "Vendor delay impacting milestone","Budget overrun forecast",
            "Resource shortage","Cyber security vulnerability detected",
            "Scope creep","Integration risk","Regulatory change",
            "Stakeholder alignment risk","Technology obsolescence"]),
        "Probability": random.choice(["Low","Medium","High"]),
        "Impact":      random.choice(["Low","Medium","High","Critical"]),
        "Velocity":    random.choice(["Slow","Medium","Fast"]),
        "Owner":       random.choice(PMS),
        "Mitigation Plan": random.choice([
            "Add buffer","Engage vendor","Rebaseline budget","Patch & monitoring",
            "Increase staffing","Stakeholder workshop"]),
        "Status":      random.choice(["Open","Open","Mitigated","Closed"]),
    })
df_risks = pd.DataFrame(risks)

# Governance: one current stage per project + audit history
gov_rows = []
for p in projects:
    cur = random.choice(STAGES)
    gov_rows.append({"Project ID": p["Project ID"], "Stage": cur,
                     "Gate Status": random.choice(["Approved","Pending","Rejected"]),
                     "Approval Owner": p["Sponsor"],
                     "Date": pd.Timestamp("2026-01-01") + pd.Timedelta(days=random.randint(0,180)),
                     "Checklist Complete %": random.randint(40,100),
                     "Next Gate": STAGES[min(STAGES.index(cur)+1, len(STAGES)-1)]})
df_gov = pd.DataFrame(gov_rows)

# Financials monthly
fin_rows = []
months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
for p in projects:
    for m in months:
        capex = round(p["Budget"] * random.uniform(0.05, 0.12), 0)
        opex  = round(capex * random.uniform(0.2, 0.6), 0)
        actual = round((capex+opex) * random.uniform(0.6, 1.1), 0)
        forecast = round((capex+opex) * random.uniform(0.9, 1.15), 0)
        fin_rows.append({"Project ID": p["Project ID"],
                         "CAPEX": capex, "OPEX": opex,
                         "Actual": actual, "Forecast": forecast,
                         "Variance": forecast - actual,
                         "Planned Value": round((capex+opex) * random.uniform(0.8,1.0),0),
                         "Earned Value":  round((capex+opex) * random.uniform(0.6,1.0),0),
                         "Month": m})
df_fin = pd.DataFrame(fin_rows)

# Resources with skill
res_rows = []
for r in range(1, 31):
    name = f"Resource {r:02d}"
    skill = random.choice(SKILLS)
    for _ in range(random.randint(1,3)):
        proj = random.choice(df_projects["Project Name"].tolist())
        res_rows.append({"Resource": name, "Skill": skill, "Project": proj,
                         "Role": random.choice(["Project Manager","Developer","Tester","Analyst","Architect"]),
                         "Allocation %": random.choice([25,50,75,100])})
df_res = pd.DataFrame(res_rows)

# NEW: Dependencies (project to project)
dep_rows = []
ids = df_projects["Project ID"].tolist()
for _ in range(40):
    a, b = random.sample(ids, 2)
    dep_rows.append({"From Project": a, "To Project": b,
                     "Dependency Type": random.choice(["Finish-Start","Start-Start","Blocks","Shared Resource"]),
                     "Status": random.choice(["Healthy","At Risk","Blocked"]),
                     "Impact": random.choice(["Low","Medium","High"])})
df_dep = pd.DataFrame(dep_rows)

# NEW: Demand / Pipeline intake
pipeline_rows = []
ideas = ["Process Automation v2","Customer 360","ML Ops Platform","Edge Analytics","Green IT",
         "ESG Data Hub","Citizen Dev Studio","Quantum Pilot","SaaS Rationalisation","Zero Trust v2"]
for i, idea in enumerate(ideas, start=1):
    strat = random.randint(1,5); value = random.randint(1,5); risk = random.randint(1,5); effort = random.randint(1,5)
    score = round((strat*0.3 + value*0.4 - risk*0.15 - effort*0.15) * 20, 1)
    pipeline_rows.append({"Idea ID": f"IDEA{i:03d}", "Name": idea,
                          "Submitter": random.choice(PMS),
                          "Strategic Fit (1-5)": strat, "Value (1-5)": value,
                          "Risk (1-5)": risk, "Effort (1-5)": effort,
                          "Priority Score": score,
                          "Decision": random.choice(["New","Under Review","Approved","Rejected","Parked"]),
                          "Est. Budget ($K)": random.randint(50, 2000)})
df_pipe = pd.DataFrame(pipeline_rows).sort_values("Priority Score", ascending=False)

# NEW: Cost vs Benefit — 5-year view per project
# CAPEX is front-loaded; OPEX recurring; benefits start year 2.
# Benefit Type:  "Recurring" (every year) or "One-Off" (single year hit).
YEARS = [2025, 2026, 2027, 2028, 2029]
BENEFIT_CATEGORIES = ["Cost Savings", "Revenue Uplift", "Productivity",
                      "Risk Avoidance", "Compliance"]
cb_rows = []
for p in projects:
    btype = random.choice(["Recurring", "Recurring", "One-Off"])
    bcat  = random.choice(BENEFIT_CATEGORIES)
    total_capex = p["Budget"]
    yearly_opex = round(total_capex * random.uniform(0.05, 0.15), 0)
    # benefit baseline tied loosely to capex so ROI varies project-to-project
    base_benefit = round(total_capex * random.uniform(0.15, 0.65), 0)
    one_off_year = random.choice([2, 3])
    for idx, yr in enumerate(YEARS, start=1):
        # CAPEX in years 1-2, tapering
        if idx == 1:   capex = round(total_capex * random.uniform(0.55, 0.75), 0)
        elif idx == 2: capex = round(total_capex * random.uniform(0.20, 0.40), 0)
        else:          capex = round(total_capex * random.uniform(0.00, 0.05), 0)
        # OPEX ramps from year 2
        opex  = 0 if idx == 1 else round(yearly_opex * random.uniform(0.8, 1.2), 0)
        # Benefits
        ben_rec = ben_one = 0
        if btype == "Recurring" and idx >= 2:
            ben_rec = round(base_benefit * random.uniform(0.8, 1.2), 0)
        if btype == "One-Off" and idx == one_off_year:
            ben_one = round(base_benefit * random.uniform(1.5, 2.5), 0)
        cb_rows.append({
            "Project ID":       p["Project ID"],
            "Project Name":     p["Project Name"],
            "Program":          p["Program"],
            "Year":             yr,
            "CAPEX":            capex,
            "OPEX":             opex,
            "Total Cost":       capex + opex,
            "Benefit Recurring": ben_rec,
            "Benefit One-Off":  ben_one,
            "Total Benefit":    ben_rec + ben_one,
            "Net Benefit":      (ben_rec + ben_one) - (capex + opex),
            "Benefit Type":     btype,
            "Benefit Category": bcat,
            "Confidence %":     random.choice([60, 70, 80, 90]),
        })
df_costbenefit = pd.DataFrame(cb_rows)

with pd.ExcelWriter(OUT, engine="openpyxl") as xw:
    df_projects.to_excel(xw,    sheet_name="Projects",     index=False)
    df_roadmap.to_excel(xw,     sheet_name="Roadmap",      index=False)
    df_risks.to_excel(xw,       sheet_name="Risks",        index=False)
    df_gov.to_excel(xw,         sheet_name="Governance",   index=False)
    df_fin.to_excel(xw,         sheet_name="Financials",   index=False)
    df_res.to_excel(xw,         sheet_name="Resources",    index=False)
    df_dep.to_excel(xw,         sheet_name="Dependencies", index=False)
    df_pipe.to_excel(xw,        sheet_name="Pipeline",     index=False)
    df_costbenefit.to_excel(xw, sheet_name="CostBenefit",  index=False)

print(f"✅ Wrote {OUT}")
