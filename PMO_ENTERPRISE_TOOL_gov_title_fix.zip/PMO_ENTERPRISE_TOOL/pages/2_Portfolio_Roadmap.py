import streamlit as st
from utils.theme import apply_theme
apply_theme()
from utils.excel_loader import load_all
from utils.tab_builders import build_roadmap
from utils.exporters import render_export_buttons

st.set_page_config(layout="wide", page_title="Portfolio Roadmap")
st.title("🗺️ Portfolio Roadmap — Gantt + Governance Gates")
st.caption("◆ Diamond = current governance gate. Green=Approved, Amber=Pending, Red=Rejected.")

bundle = build_roadmap(load_all())
for _, fig in bundle["figs"]:
    st.plotly_chart(fig, use_container_width=True)
for name, df in bundle["tables"]:
    with st.expander(name):
        st.dataframe(df, use_container_width=True, hide_index=True)
render_export_buttons(bundle)
