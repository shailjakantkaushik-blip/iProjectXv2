import streamlit as st
from utils.theme import apply_theme
apply_theme()
from utils.excel_loader import load_all
from utils.tab_builders import build_governance
from utils.exporters import render_export_buttons

st.set_page_config(layout="wide", page_title="Governance")
st.title("🏛️ Governance — Stage Gates & Approvals")

bundle = build_governance(load_all())
if bundle["kpis"]:
    k = st.columns(len(bundle["kpis"]))
    for col,(l,v) in zip(k, bundle["kpis"]): col.metric(l, v)
for _, fig in bundle["figs"]: st.plotly_chart(fig, use_container_width=True)
for name, df in bundle["tables"]:
    st.dataframe(df, use_container_width=True, hide_index=True)
render_export_buttons(bundle)
