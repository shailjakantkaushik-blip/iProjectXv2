"""1 · Executive Dashboard — single-screen cockpit with per-tab export."""
import streamlit as st
from utils.excel_loader import load_all
from utils.tab_builders import build_executive
from utils.exporters import render_export_buttons
from utils.theme_manager import apply_theme, render_sheet
from utils.chart_factory import sparkline

st.set_page_config(layout="wide", page_title="Executive Dashboard")
apply_theme()

data = load_all()
projects = data["projects"].copy()

# ─────────────────────── Filter bar ───────────────────────
st.markdown("<div class='section-frame'>", unsafe_allow_html=True)
top = st.columns([2, 1, 1, 1, 1])
top[0].markdown("### 📊 PMO Portfolio — Executive Summary")

def opts(col): return ["All"] + sorted(projects[col].dropna().unique().tolist())
prog = top[1].selectbox("Program",  opts("Program"),  label_visibility="collapsed")
spon = top[2].selectbox("Sponsor",  opts("Sponsor"),  label_visibility="collapsed")
prio = top[3].selectbox("Priority", opts("Priority"), label_visibility="collapsed")
stat = top[4].selectbox("Status",   opts("Status"),   label_visibility="collapsed")
flt = projects
if prog != "All": flt = flt[flt["Program"] == prog]
if spon != "All": flt = flt[flt["Sponsor"] == spon]
if prio != "All": flt = flt[flt["Priority"] == prio]
if stat != "All": flt = flt[flt["Status"] == stat]
st.markdown("</div>", unsafe_allow_html=True)

bundle = build_executive(data, flt=flt)

# ─────────────────────── KPI row with embedded sparklines ───────────────────────
st.markdown("<div class='section-frame'>"
            "<div class='section-title'>Key Metrics</div>", unsafe_allow_html=True)
trends = bundle.get("trends", {})
TREND_COLORS = {
    "CAPEX Approved": "#3b82f6", "Incurred": "#22c55e",
    "Forecast": "#f59e0b",       "Remaining": "#8b5cf6",
    "Active": "#06b6d4",          "Completed": "#22c55e",
    "Overdue": "#ef4444",         "RAG Score": "#a855f7",
}
cols = st.columns(len(bundle["kpis"]))
for col, (lbl, val) in zip(cols, bundle["kpis"]):
    with col:
        st.markdown(
            f"<div class='kpi-card'>"
            f"<div class='kpi-label'>{lbl}</div>"
            f"<div class='kpi-value'>{val}</div></div>",
            unsafe_allow_html=True)
        series = trends.get(lbl)
        if series:
            spk = sparkline(series, color=TREND_COLORS.get(lbl, "#3b82f6"))
            spk.update_layout(height=42, margin=dict(l=0, r=0, t=0, b=0))
            st.plotly_chart(spk, use_container_width=True,
                            config={"displayModeBar": False})
st.markdown("</div>", unsafe_allow_html=True)

# ─────────────────────── Portfolio Analytics (charts) ───────────────────────
gov_fig = next((f for n, f in bundle["figs"] if n == "Governance Flow"), None)
figs = [(n, f) for (n, f) in bundle["figs"] if n != "Governance Flow"]
st.markdown("<div class='section-frame'>"
            "<div class='section-title'>Portfolio Analytics</div>", unsafe_allow_html=True)
for i in range(0, len(figs), 3):
    row = st.columns(3)
    for col, (name, fig) in zip(row, figs[i:i+3]):
        fig.update_layout(height=240, margin=dict(l=10, r=10, t=35, b=10))
        col.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
st.markdown("</div>", unsafe_allow_html=True)

# ─────────────────────── Governance Flow (positioned after analytics) ───────────────────────
if gov_fig is not None:
    st.markdown("<div class='section-frame'>"
                "<div class='section-title'>Governance Flow — current stage per project</div>",
                unsafe_allow_html=True)
    st.plotly_chart(gov_fig, use_container_width=True,
                    config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)

# ─────────────────────── Top risks ───────────────────────
for name, df in bundle["tables"]:
    st.markdown(f"<div class='section-frame'>"
                f"<div class='section-title'>{name}</div>", unsafe_allow_html=True)
    render_sheet(df, max_rows=200)
    st.markdown("</div>", unsafe_allow_html=True)

render_export_buttons(bundle)
