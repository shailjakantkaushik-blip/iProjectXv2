import streamlit as st
from utils.theme_manager import apply_theme, render_sheet
from utils.excel_loader import load_all
from utils.tab_builders import build_projects
from utils.exporters import render_export_buttons

st.set_page_config(layout="wide", page_title="Projects")
apply_theme()
st.title("📁 Project Register")

projects = load_all()["projects"]
c1, c2, c3 = st.columns(3)
prog = c1.multiselect("Program", sorted(projects["Program"].dropna().unique()))
stat = c2.multiselect("Status",  sorted(projects["Status"].dropna().unique()))
rag  = c3.multiselect("RAG",     sorted(projects["RAG"].dropna().unique()))
flt = projects
if prog: flt = flt[flt["Program"].isin(prog)]
if stat: flt = flt[flt["Status"].isin(stat)]
if rag:  flt = flt[flt["RAG"].isin(rag)]

data = load_all(); data = {**data, "projects": flt}
bundle = build_projects(data)
k = st.columns(len(bundle["kpis"]))
for col,(l,v) in zip(k, bundle["kpis"]): col.metric(l, v)
r = st.columns(len(bundle["figs"]) or 1)
for col,(name,fig) in zip(r, bundle["figs"]): col.plotly_chart(fig, use_container_width=True)

# Sheet view — use the merged register from the bundle so the Current Phase,
# Gate Status, Next Gate and Checklist % columns are visible per row.
register_df = bundle["tables"][0][1]
front = [c for c in ["Project ID", "Project Name", "Program", "Sponsor",
                     "Priority", "Status", "RAG",
                     "Current Phase", "Gate Status", "Next Gate",
                     "Checklist Complete %"] if c in register_df.columns]
ordered = front + [c for c in register_df.columns if c not in front]
render_sheet(register_df[ordered])
render_export_buttons(bundle)

