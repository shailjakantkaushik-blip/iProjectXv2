"""PMO Enterprise Tool — main entry. Run: streamlit run app.py"""
import streamlit as st
from pathlib import Path
from config import (get_master_file, set_master_file, DEFAULT_MASTER_FILE,
                    UPLOAD_DIR)
from utils.excel_loader import load_all, refresh
from utils.ppt_export import build_portfolio_ppt
from utils.theme_manager import apply_theme, theme_picker_sidebar

st.set_page_config(page_title="PMO Portfolio | Enterprise",
                   page_icon="📊", layout="wide", initial_sidebar_state="expanded")
apply_theme()

st.sidebar.image("https://cdn-icons-png.flaticon.com/512/2103/2103633.png", width=60)
st.sidebar.title("PMO PORTFOLIO")
st.sidebar.caption("ENTERPRISE EDITION")

# Theme picker (light / dark / custom)
theme_picker_sidebar()

# ─────────────────────────── DATA SOURCE PANEL ───────────────────────────
st.sidebar.markdown("### 📂 Data Source")
current = get_master_file()
st.sidebar.caption(f"Active: `{current.name}`")
with st.sidebar.expander("Change Excel data source", expanded=False):
    st.markdown("**Option A · Type a local or synced path**")
    st.caption("Works with any local `.xlsx`, OneDrive-synced folders, and "
               "SharePoint document libraries synced to your PC.")
    new_path = st.text_input("File path",
        value=str(current),
        placeholder=r"C:\Users\you\OneDrive - Contoso\PMO\PMO_Master.xlsx",
        label_visibility="collapsed")
    if st.button("Use this path", use_container_width=True):
        p = Path(new_path).expanduser()
        if not p.exists():
            st.error(f"File not found: {p}")
        elif p.suffix.lower() not in {".xlsx", ".xlsm"}:
            st.error("File must be .xlsx or .xlsm")
        else:
            set_master_file(p); refresh()
            st.success(f"Switched to {p.name}"); st.rerun()

    st.markdown("---")
    st.markdown("**Option B · Upload an Excel file**")
    up = st.file_uploader("Upload .xlsx", type=["xlsx","xlsm"],
                          label_visibility="collapsed")
    if up is not None:
        dest = UPLOAD_DIR / up.name
        dest.write_bytes(up.getbuffer())
        set_master_file(dest); refresh()
        st.success(f"Uploaded & activated: {up.name}"); st.rerun()

    st.markdown("---")
    st.markdown("**Option C · SharePoint URL → guidance**")
    st.caption(
        "Streamlit running locally cannot fetch SharePoint URLs directly "
        "without auth. Recommended pattern:\n\n"
        "1. In SharePoint, open the document library and click **Sync** "
        "(installs the OneDrive sync client).\n"
        "2. The library appears under e.g. "
        "`C:\\Users\\<you>\\<Tenant>\\<SiteName> - Documents\\`.\n"
        "3. Paste that full local path above in **Option A**.\n\n"
        "The file stays in SharePoint; OneDrive keeps your local copy in sync, "
        "so the dashboard always reads live data.")

    if st.button("↩︎ Reset to bundled sample",
                 use_container_width=True):
        set_master_file(DEFAULT_MASTER_FILE); refresh()
        st.rerun()

st.sidebar.markdown("---")
if st.sidebar.button("🔄 Refresh Data"):
    refresh(); st.rerun()

# ─────────────────────────── EXPORT ───────────────────────────
st.sidebar.markdown("### 📤 Export Portfolio Deck")
if st.sidebar.button("Generate PowerPoint"):
    with st.spinner("Building portfolio deck..."):
        path = build_portfolio_ppt()
    st.sidebar.success("Deck ready!")
    with open(path, "rb") as f:
        st.sidebar.download_button("⬇️ Download .pptx", f.read(),
            file_name=Path(path).name,
            mime="application/vnd.openxmlformats-officedocument.presentationml.presentation")

# ─────────────────────────── MAIN ───────────────────────────
master = get_master_file()
if not master.exists():
    st.error(f"Master file missing: {master}\n\n"
             f"Run `python generate_master.py` or pick a file in the sidebar.")
    st.stop()

st.title("📊 PMO Portfolio — Enterprise Cockpit")
st.caption(f"Live data source: **{master}**")
st.markdown(
    "Use the sidebar to navigate. Modules:\n\n"
    "1 · **Executive Dashboard** · 2 · **Portfolio Roadmap** · 3 · **Projects** · "
    "4 · **Risks** · 5 · **Financials** · 6 · **Governance** · "
    "7 · **Resources** · 8 · **Roadmap Analytics** · "
    "9 · **Dependencies** · 10 · **Demand Pipeline**"
)

data = load_all(str(master))
c = st.columns(8)
c[0].metric("Projects",     len(data["projects"]))
c[1].metric("Risks",        len(data["risks"]))
c[2].metric("Resources",    len(data["resources"]))
c[3].metric("Gov. Items",   len(data["governance"]))
c[4].metric("Financials",   len(data["financials"]))
c[5].metric("Roadmap Rows", len(data["roadmap"]))
c[6].metric("Dependencies", len(data["dependencies"]))
c[7].metric("Pipeline",     len(data["pipeline"]))

st.info("👉 Open **1 · Executive Dashboard** from the left sidebar to begin.")
