"""Load PMO data from the active master Excel workbook with caching.

Robust to schema changes: any extra columns you add in Excel flow through
automatically, and any sheet present in the workbook is exposed under
`data["_sheets"][<exact-sheet-name>]` so new sheets work without code
changes. Sheet-name matching for the canonical keys (projects, risks, …)
is case/whitespace-insensitive.
"""
from __future__ import annotations
import pandas as pd
import streamlit as st
from config import get_master_file, SHEETS


def _norm(s: str) -> str:
    return "".join(str(s).lower().split())


@st.cache_data(show_spinner=False)
def load_all(path_str: str | None = None) -> dict:
    p = path_str or str(get_master_file())
    xls = pd.ExcelFile(p, engine="openpyxl")

    # Read every sheet present in the workbook
    raw: dict[str, pd.DataFrame] = {}
    for s in xls.sheet_names:
        try:
            df = pd.read_excel(xls, sheet_name=s)
            df.columns = [str(c).strip() for c in df.columns]
            raw[s] = df
        except Exception:
            raw[s] = pd.DataFrame()

    # Map canonical keys → first sheet whose name matches (case-insensitive)
    norm_map = {_norm(s): s for s in raw}
    data: dict = {}
    for key, sheet in SHEETS.items():
        match = norm_map.get(_norm(sheet))
        data[key] = raw[match].copy() if match else pd.DataFrame()

    # Expose raw sheets for power users / extra-sheet introspection
    data["_sheets"] = raw
    return data


def refresh():
    load_all.clear()
