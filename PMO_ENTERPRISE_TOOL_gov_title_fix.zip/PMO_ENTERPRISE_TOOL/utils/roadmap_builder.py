"""Gantt-style roadmap that overlays the FULL governance workflow
(all stage gates) on every project bar and highlights the current gate.
"""
from __future__ import annotations
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from config import RAG_COLORS, STAGES
from utils.chart_factory import DARK_LAYOUT


_GATE_COLOR = {"Approved": "#22c55e", "Pending": "#f59e0b", "Rejected": "#ef4444"}


def gantt(projects: pd.DataFrame, governance: pd.DataFrame | None = None, height: int = 650):
    df = projects.dropna(subset=["Start Date", "End Date"]).copy()
    if df.empty:
        return None
    df["Start Date"] = pd.to_datetime(df["Start Date"])
    df["End Date"]   = pd.to_datetime(df["End Date"])
    df["RAG"] = df.get("RAG", "Green").fillna("Green")

    fig = px.timeline(
        df, x_start="Start Date", x_end="End Date", y="Project Name",
        color="RAG", color_discrete_map=RAG_COLORS,
        hover_data=["Status", "Program", "Sponsor"],
        opacity=0.55,
    )
    fig.update_yaxes(autorange="reversed")
    fig.update_layout(
        title="Portfolio Roadmap — Governance Workflow (all gates, ◆ = current)",
        height=height, **DARK_LAYOUT,
        legend=dict(
            orientation="v",
            yanchor="top", y=1,
            xanchor="left", x=1.02,
            bgcolor="rgba(0,0,0,0)",
            title=dict(text="RAG"),
        ),
    )
    # Widen right margin to make room for vertical legend
    _m = dict(DARK_LAYOUT.get("margin", {}))
    _m["r"] = 160
    fig.update_layout(margin=_m)

    n = len(STAGES)
    # Current stage lookup
    current_stage = {}
    current_status = {}
    if governance is not None and not governance.empty:
        g = governance.copy()
        for _, row in g.iterrows():
            pid = row.get("Project ID")
            current_stage[pid] = row.get("Stage")
            current_status[pid] = row.get("Gate Status")

    # Plot ALL gates for every project as small ticks along its bar
    all_x, all_y, all_text, all_hover = [], [], [], []
    cur_x, cur_y, cur_text, cur_color, cur_hover = [], [], [], [], []

    for _, r in df.iterrows():
        pid = r.get("Project ID")
        name = r["Project Name"]
        span = (r["End Date"] - r["Start Date"])
        for i, stage in enumerate(STAGES):
            x = r["Start Date"] + span * ((i + 0.5) / n)
            is_current = current_stage.get(pid) == stage
            if is_current:
                cur_x.append(x); cur_y.append(name); cur_text.append(stage)
                cur_color.append(_GATE_COLOR.get(current_status.get(pid), "#94a3b8"))
                cur_hover.append(f"<b>{name}</b><br>Current Gate: {stage}"
                                 f"<br>Status: {current_status.get(pid,'—')}")
            else:
                all_x.append(x); all_y.append(name); all_text.append(stage)
                all_hover.append(f"{name}<br>Gate: {stage}")

    # All upcoming/past gates (small grey ticks with stage initial)
    if all_x:
        fig.add_trace(go.Scatter(
            x=all_x, y=all_y, mode="markers+text",
            marker=dict(symbol="line-ns", size=14,
                        color="#cbd5e1",
                        line=dict(color="#cbd5e1", width=2)),
            text=[s[:1] for s in all_text],
            textposition="top center",
            textfont=dict(size=8, color="#94a3b8"),
            name="Gate (planned)",
            hovertext=all_hover, hoverinfo="text",
        ))

    # Current gate — large diamond with full label
    if cur_x:
        fig.add_trace(go.Scatter(
            x=cur_x, y=cur_y, mode="markers+text",
            marker=dict(symbol="diamond", size=18, color=cur_color,
                        line=dict(color="white", width=2)),
            text=cur_text, textposition="top center",
            textfont=dict(size=10, color="#e2e8f0", family="Arial Black"),
            name="Current Gate",
            hovertext=cur_hover, hoverinfo="text",
        ))

    return fig
