"""Theme manager for PMO Enterprise Tool.

Supports three modes:
  * dark   — original navy cockpit theme
  * light  — off-white / light-grey palette (default for light mode)
  * custom — user-defined colours (sidebar pickers)

Choice is persisted in `data/theme.json` so it survives reruns.

Public API:
    get_theme()          -> dict of palette tokens
    plotly_layout()      -> dict for Plotly figures (paper/plot/font colours + faint grid)
    apply_theme()        -> inject global CSS (also writes faint section borders)
    theme_picker_sidebar() -> renders the sidebar Theme panel
"""
from __future__ import annotations
import json
from pathlib import Path
import streamlit as st

from config import DATA_DIR

THEME_FILE = DATA_DIR / "theme.json"

# ─────────────────────────── Presets ───────────────────────────
PRESETS = {
    "dark": {
        "mode": "dark",
        "bg":          "#0f172a",
        "surface":     "#1e293b",
        "sidebar":     "#111827",
        "text":        "#f8fafc",
        "heading":     "#ffffff",   # bright white for headings & chart titles
        "muted":       "#cbd5e1",
        "border":      "#475569",
        "accent":      "#60a5fa",
        "accent2":     "#4ade80",
        "grid":        "rgba(226,232,240,0.18)",
    },
    "light": {
        "mode": "light",
        "bg":          "#f5f6f8",
        "surface":     "#ffffff",
        "sidebar":     "#e9edf2",
        "text":        "#0b1220",
        "heading":     "#0b1220",   # near-black headings on light bg
        "muted":       "#374151",
        "border":      "#d1d5db",
        "accent":      "#1d4ed8",
        "accent2":     "#15803d",
        "grid":        "rgba(11,18,32,0.10)",
    },
}

# Immutable copy of preset defaults — used for "Reset to default".
import copy as _copy
_PRESET_DEFAULTS = _copy.deepcopy(PRESETS)


# ─────────────────────────── Storage ───────────────────────────
def _load() -> dict:
    if THEME_FILE.exists():
        try:
            return json.loads(THEME_FILE.read_text())
        except Exception:
            pass
    return {"preset": "light", "custom": dict(_PRESET_DEFAULTS["light"]),
            "overrides": {}}


def _save(cfg: dict) -> None:
    THEME_FILE.write_text(json.dumps(cfg, indent=2))


def get_theme() -> dict:
    cfg = _load()
    preset = cfg.get("preset", "light")
    if preset == "custom":
        return {**_PRESET_DEFAULTS["light"], **cfg.get("custom", {})}
    overrides = cfg.get("overrides", {}).get(preset, {})
    return {**_PRESET_DEFAULTS.get(preset, _PRESET_DEFAULTS["light"]), **overrides}


# ─────────────────────────── Plotly ───────────────────────────
def plotly_layout(height: int | None = None) -> dict:
    t = get_theme()
    heading = t.get("heading", t["text"])
    layout = dict(
        paper_bgcolor=t["surface"],
        plot_bgcolor=t["surface"],
        font=dict(color=t["text"], size=11),
        title_font_color=heading,
        title_font_size=14,
        legend_font_color=t["text"],
        margin=dict(l=10, r=10, t=35, b=10),
        xaxis=dict(gridcolor=t["grid"], zerolinecolor=t["grid"],
                   tickfont=dict(color=t["text"]),
                   title=dict(font=dict(color=heading))),
        yaxis=dict(gridcolor=t["grid"], zerolinecolor=t["grid"],
                   tickfont=dict(color=t["text"]),
                   title=dict(font=dict(color=heading))),
    )
    if height is not None:
        layout["height"] = height
    return layout


# ─────────────────────────── CSS ───────────────────────────
def _css(t: dict) -> str:
    return f"""
<style>
#MainMenu, header, footer,
[data-testid="stToolbar"],
[data-testid="stDecoration"],
[data-testid="stStatusWidget"],
[data-testid="stHeader"],
.stDeployButton, .stAppDeployButton {{
    visibility: hidden !important;
    height: 0 !important;
    position: fixed !important;
    z-index: -1 !important;
}}
.stApp {{ background-color: {t['bg']}; color: {t['text']}; }}
.stApp p, .stApp span, .stApp label, .stApp li, .stApp div,
[data-testid="stMarkdownContainer"] p,
[data-testid="stMarkdownContainer"] span,
[data-testid="stMarkdownContainer"] li,
[data-testid="stMarkdownContainer"] div {{
    color: {t['text']};
}}
.stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp h5, .stApp h6,
[data-testid="stMarkdownContainer"] h1,
[data-testid="stMarkdownContainer"] h2,
[data-testid="stMarkdownContainer"] h3,
[data-testid="stMarkdownContainer"] h4,
[data-testid="stMarkdownContainer"] h5,
[data-testid="stMarkdownContainer"] h6 {{
    color: {t.get('heading', t['text'])} !important;
}}
[data-testid="stSidebar"] {{ background-color: {t['sidebar']}; }}
[data-testid="stSidebar"] * {{ color: {t['text']}; }}
.block-container {{ padding-top: 0.5rem; padding-bottom: 0.5rem; max-width: 100%; }}

/* Faint section frames (very light lines) */
.section-frame {{
    border: 1px solid {t['border']};
    border-radius: 10px;
    padding: 10px 12px;
    margin-bottom: 10px;
    background: {t['surface']};
}}
.section-title {{
    font-size: 12px;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: {t.get('heading', t['text'])};
    margin: 0 0 6px 0;
    font-weight: 700;
}}

.kpi-card {{
    background: {t['surface']};
    border: 1px solid {t['border']};
    border-radius: 8px;
    padding: 8px 10px;
}}
.kpi-label {{ font-size: 9px; color: {t['muted']}; letter-spacing: 1px; text-transform: uppercase; }}
.kpi-value {{ font-size: 20px; font-weight: 700; color: {t.get('heading', t['text'])}; margin-top: 1px; }}
h1, h2, h3 {{ margin-top: 0.2rem; margin-bottom: 0.3rem; color: {t.get('heading', t['text'])} !important; }}

/* Governance flow nodes */
.gov-flow {{ display: flex; align-items: stretch; gap: 4px; overflow-x: auto; }}
.gov-stage {{
    flex: 1 1 0; min-width: 110px;
    border: 1px solid {t['border']}; border-radius: 8px;
    padding: 8px; background: {t['surface']};
    position: relative;
}}
.gov-stage.active {{ border-color: {t['accent']}; box-shadow: 0 0 0 2px {t['accent']}33; }}
.gov-stage-head {{
    display:flex; align-items:center; gap:6px;
    font-weight:700; font-size:12px; color:{t['text']};
    border-bottom:1px solid {t['border']}; padding-bottom:4px; margin-bottom:6px;
}}
.gov-dot {{
    width:18px; height:18px; border-radius:50%; flex:none;
    display:inline-flex; align-items:center; justify-content:center;
    font-size:10px; color:#fff; background:{t['accent']};
}}
.gov-proj {{
    font-size:10.5px; color:{t['text']}; padding:2px 0;
    border-top:1px dashed {t['border']};
}}
.gov-proj:first-of-type {{ border-top: none; }}
.gov-arrow {{
    align-self:center; color:{t['muted']}; font-size:18px; padding:0 2px;
}}

/* ─────────────── Widget theming (buttons, inputs, dropdowns, tables) ─────────────── */

/* Buttons */
.stApp .stButton > button,
.stApp .stDownloadButton > button,
.stApp [data-testid="baseButton-secondary"],
.stApp [data-testid="baseButton-primary"] {{
    background-color: {t['surface']} !important;
    color: {t['text']} !important;
    border: 1px solid {t['border']} !important;
    border-radius: 6px !important;
}}
.stApp .stButton > button:hover,
.stApp .stDownloadButton > button:hover {{
    border-color: {t['accent']} !important;
    color: {t['accent']} !important;
    background-color: {t['surface']} !important;
}}

/* Text / number / date inputs */
.stApp input, .stApp textarea,
.stApp [data-baseweb="input"] input,
.stApp [data-baseweb="textarea"] textarea {{
    background-color: {t['surface']} !important;
    color: {t['text']} !important;
    border-color: {t['border']} !important;
}}

/* Selectbox & multiselect (BaseWeb) */
.stApp [data-baseweb="select"] > div,
.stApp [data-baseweb="select"] [role="combobox"],
.stApp [data-baseweb="select"] input {{
    background-color: {t['surface']} !important;
    color: {t['text']} !important;
    border-color: {t['border']} !important;
}}
.stApp [data-baseweb="select"] svg {{ fill: {t['muted']} !important; }}
.stApp [data-baseweb="tag"] {{
    background-color: {t['sidebar']} !important;
    color: {t['text']} !important;
    border: 1px solid {t['border']} !important;
}}
/* Popover/menu (selectbox dropdown panel — rendered at document root) */
[data-baseweb="popover"], [data-baseweb="popover"] *,
[data-baseweb="menu"], [data-baseweb="menu"] *,
[role="listbox"], [role="listbox"] * {{
    background-color: {t['surface']} !important;
    color: {t['text']} !important;
}}
[role="option"]:hover,
[data-baseweb="menu"] li:hover {{
    background-color: {t['sidebar']} !important;
    color: {t['text']} !important;
}}

/* Radio & checkbox labels */
.stApp .stRadio label, .stApp .stCheckbox label {{ color: {t['text']} !important; }}

/* Slider track/thumb */
.stApp [data-baseweb="slider"] [role="slider"] {{ background-color: {t['accent']} !important; }}

/* Tabs */
.stApp [data-baseweb="tab-list"] {{ background-color: {t['surface']} !important; border-bottom: 1px solid {t['border']} !important; }}
.stApp [data-baseweb="tab"] {{ color: {t['muted']} !important; }}
.stApp [data-baseweb="tab"][aria-selected="true"] {{ color: {t['accent']} !important; }}

/* Expander */
.stApp [data-testid="stExpander"] {{
    background-color: {t['surface']} !important;
    border: 1px solid {t['border']} !important;
    border-radius: 8px !important;
}}
.stApp [data-testid="stExpander"] summary,
.stApp [data-testid="stExpander"] details > summary {{ color: {t['text']} !important; }}

/* Metric */
.stApp [data-testid="stMetric"] {{
    background-color: {t['surface']};
    border: 1px solid {t['border']};
    border-radius: 8px;
    padding: 6px 10px;
}}
.stApp [data-testid="stMetricLabel"] {{ color: {t['muted']} !important; }}
.stApp [data-testid="stMetricValue"] {{ color: {t['text']} !important; }}

/* Dataframe / data editor (sheet view) */
.stApp [data-testid="stDataFrame"], .stApp [data-testid="stDataFrameResizable"],
.stApp [data-testid="stDataEditor"] {{
    background-color: {t['surface']} !important;
    border: 1px solid {t['border']} !important;
    border-radius: 8px !important;
}}
.stApp [data-testid="stDataFrame"] *,
.stApp [data-testid="stDataEditor"] * {{ color: {t['text']} !important; }}
/* glide-data-grid canvas wrapper */
.stApp [data-testid="stDataFrame"] .dvn-stack,
.stApp [data-testid="stDataFrame"] .gdg-wmyidgi,
.stApp [data-testid="stDataFrame"] [class*="GridScroller"],
.stApp [data-testid="stDataFrame"] [class*="DataEditor"] {{
    background-color: {t['surface']} !important;
    color: {t['text']} !important;
}}

/* File uploader */
.stApp [data-testid="stFileUploader"] section {{
    background-color: {t['surface']} !important;
    border: 1px dashed {t['border']} !important;
    color: {t['text']} !important;
}}

/* Alerts keep their semantic colours but tone surface to match */
.stApp [data-testid="stAlert"] {{ border: 1px solid {t['border']} !important; }}

/* Code blocks */
.stApp code, .stApp pre {{
    background-color: {t['sidebar']} !important;
    color: {t['text']} !important;
}}

/* Themed HTML sheet view (fallback so values are always visible) */
.themed-sheet-wrap {{
    max-height: 480px; overflow: auto;
    border: 1px solid {t['border']}; border-radius: 8px;
    background: {t['surface']};
}}
.themed-sheet {{
    width: 100%; border-collapse: collapse; font-size: 12px;
    color: {t['text']}; background: {t['surface']};
}}
.themed-sheet thead th {{
    position: sticky; top: 0; z-index: 2;
    background: {t['sidebar']}; color: {t['text']};
    text-align: left; padding: 8px 10px;
    border-bottom: 2px solid {t['border']};
    font-weight: 600; white-space: nowrap;
}}
.themed-sheet tbody td {{
    padding: 6px 10px; border-bottom: 1px solid {t['border']};
    color: {t['text']}; white-space: nowrap;
}}
.themed-sheet tbody tr:hover td {{ background: {t['sidebar']}; }}
</style>
"""


def render_sheet(df, max_rows: int = 500) -> None:
    """Render a DataFrame as a themed HTML table so values are always visible
    regardless of Streamlit's canvas dataframe theme."""
    import html as _html
    if df is None or len(df) == 0:
        st.info("No rows to display.")
        return
    head = "".join(f"<th>{_html.escape(str(c))}</th>" for c in df.columns)
    rows = []
    for _, r in df.head(max_rows).iterrows():
        cells = "".join(f"<td>{_html.escape('' if pd_isna(v) else str(v))}</td>" for v in r.tolist())
        rows.append(f"<tr>{cells}</tr>")
    html = (f"<div class='themed-sheet-wrap'><table class='themed-sheet'>"
            f"<thead><tr>{head}</tr></thead><tbody>{''.join(rows)}</tbody></table></div>")
    st.markdown(html, unsafe_allow_html=True)
    if len(df) > max_rows:
        st.caption(f"Showing first {max_rows:,} of {len(df):,} rows.")


def pd_isna(v) -> bool:
    try:
        import pandas as pd
        return bool(pd.isna(v))
    except Exception:
        return v is None


def apply_theme() -> None:
    st.markdown(_css(get_theme()), unsafe_allow_html=True)


# ─────────────────────────── Sidebar picker ───────────────────────────
_CUSTOMISABLE_KEYS = [
    ("bg",       "Background"),
    ("surface",  "Surface / cards"),
    ("sidebar",  "Sidebar"),
    ("text",     "Body text"),
    ("heading",  "Headings & chart titles"),
    ("muted",    "Muted text"),
    ("border",   "Section lines"),
    ("accent",   "Accent"),
    ("accent2",  "Accent 2"),
]


def theme_picker_sidebar() -> None:
    cfg = _load()
    with st.sidebar.expander("🎨 Theme", expanded=False):
        choice = st.radio(
            "Mode",
            ["light", "dark", "custom"],
            index=["light", "dark", "custom"].index(cfg.get("preset", "light")),
            horizontal=True,
        )
        if choice != cfg.get("preset"):
            cfg["preset"] = choice
            if choice == "custom" and "custom" not in cfg:
                cfg["custom"] = dict(PRESETS["light"])
            _save(cfg); st.rerun()

        st.markdown("---")
        st.caption(f"Customise colours for the **{choice}** theme.")

        if choice == "custom":
            base = cfg.get("custom") or dict(PRESETS["light"])
        else:
            overrides = cfg.get("overrides", {}).get(choice, {})
            base = {**_PRESET_DEFAULTS[choice], **overrides}

        new = dict(base)
        for k, label in _CUSTOMISABLE_KEYS:
            default = base.get(k, _PRESET_DEFAULTS["light"].get(k, "#000000"))
            new[k] = st.color_picker(label, default, key=f"theme_{choice}_{k}")
        new["grid"] = base.get("grid", _PRESET_DEFAULTS[choice if choice != 'custom' else 'light']["grid"])

        c1, c2 = st.columns(2)
        with c1:
            if st.button("Apply", use_container_width=True, key=f"apply_{choice}"):
                if choice == "custom":
                    new["mode"] = "custom"
                    cfg["custom"] = new
                else:
                    cfg.setdefault("overrides", {})[choice] = new
                _save(cfg); st.rerun()
        with c2:
            if st.button("Reset to default", use_container_width=True,
                         key=f"reset_{choice}"):
                if choice == "custom":
                    cfg["custom"] = dict(_PRESET_DEFAULTS["light"])
                else:
                    cfg.get("overrides", {}).pop(choice, None)
                _save(cfg); st.rerun()
