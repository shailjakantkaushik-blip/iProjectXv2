"""Centralised builders that produce the exact figures + tables each tab shows.
Both the page renderers and the global PPT exporter use these — guaranteeing
PPT/PDF/Image exports look identical to the live tab.

Each builder returns:
  {"title": str, "subtitle": str,
   "figs":   [(name, plotly.graph_objects.Figure), ...],
   "tables": [(name, pandas.DataFrame), ...],
   "kpis":   [(label, value), ...]}
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from config import STAGES, RAG_COLORS
from utils.chart_factory import (donut_rag, bar_capex_vs_actual, line_monthly_spend,
                                 donut_theme, bar_priority, governance_funnel,
                                 governance_flow_plotly, DARK_LAYOUT)
from utils.kpi_engine import compute_kpis, rag_distribution, by_theme, by_priority, kpi_trends
from utils.risk_engine import score_risks
from utils.roadmap_builder import gantt


# ───────────────────────── 1 · Executive Dashboard ─────────────────────────
def build_executive(data, flt=None):
    projects   = flt if flt is not None else data["projects"]
    financials = data["financials"]
    risks      = data["risks"]
    gov        = data["governance"]
    k = compute_kpis(projects, financials)
    figs = [
        ("Governance Flow",   governance_flow_plotly(gov, projects_df=projects, height=340)),
        ("Portfolio Health",  donut_rag(rag_distribution(projects), height=320)),
        ("CAPEX vs Actual",   bar_capex_vs_actual(k, height=320)),
        ("Monthly Spend",     line_monthly_spend(financials, height=320)),
    ]
    td = by_theme(projects); pd_ = by_priority(projects)
    if not td.empty: figs.append(("By Theme",    donut_theme(td, height=320)))
    if not pd_.empty: figs.append(("By Priority", bar_priority(pd_, height=320)))

    # Top 10 Projects by ROI % (right of By Priority, below Monthly Spend)
    cb = data.get("costbenefit", pd.DataFrame())
    if cb is not None and not cb.empty:
        cb_f = cb[cb["Project ID"].isin(projects["Project ID"])] if "Project ID" in cb.columns else cb
        if not cb_f.empty:
            per = (cb_f.groupby(["Project ID","Project Name"])[["Total Cost","Total Benefit"]]
                       .sum().reset_index())
            per["ROI %"] = np.where(per["Total Cost"] > 0,
                                    (per["Total Benefit"] - per["Total Cost"]) / per["Total Cost"] * 100, 0)
            top = per.sort_values("ROI %", ascending=False).head(10).sort_values("ROI %", ascending=True)
            if not top.empty:
                f_roi = px.bar(top, x="ROI %", y="Project Name", orientation="h",
                               color="ROI %", color_continuous_scale="RdYlGn",
                               text=top["ROI %"].round(0).astype(int).astype(str) + "%")
                f_roi.update_layout(title="Top 10 Projects by ROI %", **DARK_LAYOUT,
                                    height=320, coloraxis_showscale=False)
                _m = dict(DARK_LAYOUT.get("margin", {}))
                _m.update(dict(l=10, r=10, t=40, b=10))
                f_roi.update_layout(margin=_m)
                f_roi.update_traces(textposition="outside", cliponaxis=False)
                figs.append(("Top 10 ROI", f_roi))
    top_risks = score_risks(risks).head(5)[
        ["Risk ID","Project ID","Description","Risk Score","Status"]]
    return {
        "title": "1 · Executive Dashboard",
        "subtitle": "Single-screen cockpit",
        "kpis": [
            ("CAPEX Approved", f"${k['capex_approved']/1e6:.1f}M"),
            ("Incurred",       f"${k['cost_incurred']/1e6:.1f}M"),
            ("Forecast",       f"${k['forecast']/1e6:.1f}M"),
            ("Remaining",      f"${k['remaining']/1e6:.1f}M"),
            ("Active",         k["active"]),
            ("Completed",      k["completed"]),
            ("Overdue",        k["overdue"]),
            ("RAG Score",      f"{k['avg_rag']}/5"),
        ],
        "trends": kpi_trends(projects, financials),
        "figs": figs,
        "tables": [("Top Risks", top_risks)],
    }


# ───────────────────────── 2 · Portfolio Roadmap ─────────────────────────
def build_roadmap(data):
    projects = data["projects"]; gov = data["governance"]
    fig = gantt(projects, governance=gov, height=650)
    merged = projects.merge(
        gov[["Project ID","Stage","Gate Status","Next Gate"]], on="Project ID", how="left")
    tbl = merged[["Project ID","Project Name","Program","Status","RAG",
                  "Start Date","End Date","Stage","Gate Status","Next Gate"]]
    return {"title": "2 · Portfolio Roadmap",
            "subtitle": "Gantt + current governance gate (◆ marker)",
            "kpis": [("Projects", len(projects)), ("With Gate Data", merged["Stage"].notna().sum())],
            "figs": [("Roadmap with Governance Gates", fig)] if fig else [],
            "tables": [("Roadmap Detail", tbl)]}


# ───────────────────────── 3 · Projects ─────────────────────────
def build_projects(data):
    projects = data["projects"].copy()
    gov      = data.get("governance", pd.DataFrame())
    # Merge governance current phase into the register so users see, per project,
    # which stage gate the project is currently at and its approval status.
    if not gov.empty and "Project ID" in projects.columns and "Project ID" in gov.columns:
        gcols = [c for c in ["Project ID", "Stage", "Gate Status", "Next Gate",
                             "Checklist Complete %"] if c in gov.columns]
        projects = projects.merge(
            gov[gcols].rename(columns={"Stage": "Current Phase",
                                       "Gate Status": "Gate Status",
                                       "Next Gate": "Next Gate"}),
            on="Project ID", how="left")
    rag_fig = donut_rag(rag_distribution(projects), height=320)
    prog = projects.groupby("Program").size().reset_index(name="Count").sort_values("Count", ascending=False)
    fig = px.bar(prog, x="Program", y="Count", color="Count", color_continuous_scale="Blues")
    fig.update_layout(title="Projects by Program", **DARK_LAYOUT, height=320)

    # Phase distribution chart (only if we have governance data)
    figs = [("RAG Distribution", rag_fig), ("Projects by Program", fig)]
    if "Current Phase" in projects.columns and projects["Current Phase"].notna().any():
        phase = (projects["Current Phase"].fillna("Unassigned")
                 .value_counts().reindex(STAGES + ["Unassigned"]).dropna()
                 .reset_index())
        phase.columns = ["Phase", "Count"]
        fph = px.bar(phase, x="Phase", y="Count", color="Count",
                     color_continuous_scale="Tealgrn")
        fph.update_layout(title="Current Governance Phase Distribution",
                          **DARK_LAYOUT, height=320)
        figs.append(("Governance Phase", fph))

    return {"title": "3 · Project Register",
            "subtitle": f"{len(projects)} projects · current phase shown per row",
            "kpis": [("Total", len(projects)),
                     ("Active",    int((projects.get("Status")=="Active").sum())),
                     ("Completed", int((projects.get("Status")=="Completed").sum())),
                     ("Pipeline",  int((projects.get("Status")=="Pipeline").sum()))],
            "figs": figs,
            "tables": [("Project Register (with Current Phase)", projects)]}


# ───────────────────────── 4 · Risks ─────────────────────────
def build_risks(data):
    risks = score_risks(data["risks"])
    figs = []
    if not risks.empty:
        f = px.scatter(risks, x="Probability", y="Impact", size="Risk Score",
                       color="Risk Score", hover_data=["Description","Owner"],
                       color_continuous_scale="Reds")
        f.update_layout(title="Risk Heatmap (P × I)", **DARK_LAYOUT, height=400)
        figs.append(("Risk Heatmap", f))
    return {"title": "4 · Risk Intelligence",
            "subtitle": "Score = Probability × Impact × Velocity",
            "kpis": [("Total Risks", len(risks)),
                     ("Escalated",   int(risks.get("Escalate", pd.Series([])).sum()) if not risks.empty else 0),
                     ("Avg Score",   round(risks["Risk Score"].mean(),1) if not risks.empty else 0)],
            "figs": figs,
            "tables": [("Scored Risks", risks)]}


# ───────────────────────── 5 · Financials ─────────────────────────
def build_financials(data):
    fin = data["financials"]
    if fin.empty:
        return {"title":"5 · Financials","subtitle":"No data","kpis":[],"figs":[],"tables":[]}
    pv = fin["Planned Value"].sum() if "Planned Value" in fin else fin["Forecast"].sum()
    ev = fin["Earned Value"].sum()  if "Earned Value"  in fin else fin["Actual"].sum()*0.9
    ac = fin["Actual"].sum(); bac = fin["Forecast"].sum()
    spi = round(ev/pv,2) if pv else 0; cpi = round(ev/ac,2) if ac else 0
    eac = round(bac/cpi,0) if cpi else 0

    agg = fin.groupby("Project ID")[["CAPEX","OPEX"]].sum().reset_index()
    f1 = px.bar(agg, x="Project ID", y=["CAPEX","OPEX"], barmode="stack",
                color_discrete_sequence=["#3b82f6","#f59e0b"])
    f1.update_layout(title="CAPEX vs OPEX by Project", **DARK_LAYOUT, height=400)

    evm = fin.groupby("Project ID")[["Planned Value","Earned Value","Actual"]].sum().reset_index()
    f2 = px.bar(evm, x="Project ID", y=["Planned Value","Earned Value","Actual"],
                barmode="group", color_discrete_sequence=["#8b5cf6","#22c55e","#f59e0b"])
    f2.update_layout(title="Earned Value Management (PV / EV / AC)", **DARK_LAYOUT, height=400)

    return {"title":"5 · Financial Intelligence",
            "subtitle":"CAPEX / OPEX + EVM",
            "kpis":[("CAPEX",f"${fin['CAPEX'].sum()/1e6:.2f}M"),
                    ("OPEX", f"${fin['OPEX'].sum()/1e6:.2f}M"),
                    ("Actual",f"${ac/1e6:.2f}M"),
                    ("Forecast",f"${bac/1e6:.2f}M"),
                    ("SPI",spi),("CPI",cpi),("EAC",f"${eac/1e6:.2f}M")],
            "figs":[("CAPEX vs OPEX",f1),("EVM",f2)],
            "tables":[("Financials",fin)]}


# ───────────────────────── 6 · Governance ─────────────────────────
def build_governance(data):
    gov = data["governance"]
    if gov.empty:
        return {"title":"6 · Governance","subtitle":"No data","kpis":[],"figs":[],"tables":[]}
    figs = [("Stage Flow", governance_funnel(gov, height=400))]
    if "Checklist Complete %" in gov:
        f = px.bar(gov.sort_values("Checklist Complete %"), x="Project ID",
                   y="Checklist Complete %", color="Gate Status",
                   color_discrete_map={"Approved":"#22c55e","Pending":"#f59e0b","Rejected":"#ef4444"})
        f.update_layout(title="Stage Gate Checklist Completion", **DARK_LAYOUT, height=400)
        figs.append(("Checklist Completion", f))
    return {"title":"6 · Governance — Stage Gates",
            "subtitle":"Idea → Benefits Realisation",
            "kpis":[("Total",len(gov)),
                    ("Approved",int((gov["Gate Status"]=="Approved").sum())),
                    ("Pending", int((gov["Gate Status"]=="Pending").sum())),
                    ("Rejected",int((gov["Gate Status"]=="Rejected").sum()))],
            "figs":figs, "tables":[("Governance",gov)]}


# ───────────────────────── 7 · Resources ─────────────────────────
def build_resources(data):
    res = data["resources"]
    if res.empty:
        return {"title":"7 · Resources","subtitle":"No data","kpis":[],"figs":[],"tables":[]}
    util = res.groupby("Resource")["Allocation %"].sum().reset_index()
    util["Status"] = util["Allocation %"].apply(
        lambda v: "Over" if v>100 else ("Optimal" if v>=60 else "Under"))
    figs = []
    if "Skill" in res:
        sk = res.groupby("Skill")["Allocation %"].sum().reset_index().sort_values("Allocation %", ascending=False)
        f = px.bar(sk, x="Skill", y="Allocation %", color="Allocation %", color_continuous_scale="Viridis")
        f.update_layout(title="Demand by Skill", **DARK_LAYOUT, height=350)
        figs.append(("Skill Demand", f))
    pivot = res.pivot_table(index="Resource", columns="Project",
                            values="Allocation %", aggfunc="sum", fill_value=0)
    fh = px.imshow(pivot, color_continuous_scale="RdYlGn_r", aspect="auto",
                   labels=dict(color="Allocation %"))
    fh.update_layout(title="Resource × Project Heatmap", **DARK_LAYOUT, height=500)
    figs.append(("Heatmap", fh))
    return {"title":"7 · Resource Capacity",
            "subtitle":"Skill-based capacity + utilisation",
            "kpis":[("Resources",len(util)),
                    ("Over",     int((util['Status']=="Over").sum())),
                    ("Optimal",  int((util['Status']=="Optimal").sum())),
                    ("Under",    int((util['Status']=="Under").sum()))],
            "figs":figs,"tables":[("Utilisation",util)]}


# ───────────────────────── 8 · Roadmap Analytics ─────────────────────────
def build_analytics(data, mc_iterations=2000):
    projects = data["projects"]; risks = score_risks(data["risks"])
    figs = []
    if "Investment Type" in projects:
        inv = projects.groupby("Investment Type")["Budget"].sum().reset_index()
        f = px.pie(inv, names="Investment Type", values="Budget", hole=.5,
                   color_discrete_sequence=["#3b82f6","#22c55e","#f59e0b"])
        f.update_layout(title="Investment Mix", **DARK_LAYOUT, height=350)
        figs.append(("Investment Mix", f))
    if not risks.empty:
        merged = risks.merge(projects[["Project ID","Program"]], on="Project ID", how="left")
        expo = merged.groupby("Program")["Risk Score"].sum().reset_index()
        f = px.bar(expo, x="Program", y="Risk Score", color="Risk Score", color_continuous_scale="Reds")
        f.update_layout(title="Risk Exposure by Program", **DARK_LAYOUT, height=350)
        figs.append(("Risk Exposure", f))
    forecasts = projects["Forecast"].fillna(projects["Budget"]).values
    sims = np.random.normal(forecasts.sum(), 0.15*forecasts.sum(), size=mc_iterations)
    p50,p80,p95 = np.percentile(sims,[50,80,95])
    budget = projects["Budget"].sum()
    fm = go.Figure(go.Histogram(x=sims/1e6, nbinsx=40, marker_color="#3b82f6"))
    fm.add_vline(x=budget/1e6, line_color="#22c55e", annotation_text="Approved")
    fm.add_vline(x=p80/1e6,    line_color="#f59e0b", annotation_text="P80")
    fm.update_layout(title="Monte-Carlo Portfolio Cost ($M)", **DARK_LAYOUT, height=380)
    figs.append(("Monte-Carlo", fm))
    return {"title":"8 · Strategic Roadmap Analytics",
            "subtitle":"Investment mix + predictive risk",
            "kpis":[("Approved Budget",f"${budget/1e6:.1f}M"),
                    ("P50",f"${p50/1e6:.1f}M"),
                    ("P80",f"${p80/1e6:.1f}M"),
                    ("P95",f"${p95/1e6:.1f}M")],
            "figs":figs,"tables":[]}


# ───────────────────────── 9 · Dependencies ─────────────────────────
def build_dependencies(data):
    dep = data["dependencies"]
    if dep.empty:
        return {"title":"9 · Dependencies","subtitle":"No data","kpis":[],"figs":[],"tables":[]}
    matrix = pd.crosstab(dep["From Project"], dep["To Project"])
    f1 = px.imshow(matrix, aspect="auto", color_continuous_scale="Blues",
                   labels=dict(color="Links"))
    f1.update_layout(title="Dependency Matrix", **DARK_LAYOUT, height=500)
    sc = dep.groupby(["Status","Dependency Type"]).size().reset_index(name="Count")
    f2 = px.bar(sc, x="Dependency Type", y="Count", color="Status",
                color_discrete_map={"Healthy":"#22c55e","At Risk":"#f59e0b","Blocked":"#ef4444"})
    f2.update_layout(title="Dependencies by Type & Status", **DARK_LAYOUT, height=350)
    return {"title":"9 · Cross-Project Dependencies",
            "subtitle":f"{len(dep)} links",
            "kpis":[("Total",len(dep)),
                    ("Healthy",int((dep['Status']=="Healthy").sum())),
                    ("At Risk",int((dep['Status']=="At Risk").sum())),
                    ("Blocked",int((dep['Status']=="Blocked").sum()))],
            "figs":[("Matrix",f1),("By Type & Status",f2)],
            "tables":[("Dependencies",dep)]}


# ───────────────────────── 10 · Demand Pipeline ─────────────────────────
def build_pipeline(data):
    pipe = data["pipeline"]
    if pipe.empty:
        return {"title":"10 · Pipeline","subtitle":"No data","kpis":[],"figs":[],"tables":[]}
    f1 = px.bar(pipe.sort_values("Priority Score", ascending=True),
                x="Priority Score", y="Name", orientation="h",
                color="Decision",
                color_discrete_map={"Approved":"#22c55e","Under Review":"#f59e0b",
                                    "Rejected":"#ef4444","New":"#3b82f6","Parked":"#8b5cf6"})
    f1.update_layout(title="Prioritised Demand Backlog", **DARK_LAYOUT, height=500)
    f2 = px.scatter(pipe, x="Effort (1-5)", y="Value (1-5)", size="Est. Budget ($K)",
                    color="Decision", hover_data=["Name","Priority Score"])
    f2.update_layout(title="Value vs Effort", **DARK_LAYOUT, height=400)
    return {"title":"10 · Demand Pipeline",
            "subtitle":"Scored intake",
            "kpis":[("Ideas",len(pipe)),
                    ("Approved",int((pipe['Decision']=="Approved").sum())),
                    ("Avg Score",round(pipe['Priority Score'].mean(),1))],
            "figs":[("Backlog",f1),("Value vs Effort",f2)],
            "tables":[("Pipeline",pipe)]}


# ───────────────────────── 11 · Cost vs Benefit ─────────────────────────
def build_costbenefit(data):
    cb = data.get("costbenefit", pd.DataFrame())
    if cb.empty:
        return {"title": "11 · Cost vs Benefit", "subtitle": "No CostBenefit sheet found",
                "kpis": [], "figs": [], "tables": []}

    # ── KPIs ──
    tot_cost   = float(cb["Total Cost"].sum())
    tot_ben    = float(cb["Total Benefit"].sum())
    net        = tot_ben - tot_cost
    roi        = (net / tot_cost * 100) if tot_cost else 0
    bcr        = (tot_ben / tot_cost) if tot_cost else 0
    # Simple discounted payback: cumulative net by year
    by_year = (cb.groupby("Year")[["Total Cost","Total Benefit"]].sum()
                 .sort_index())
    by_year["Net"]        = by_year["Total Benefit"] - by_year["Total Cost"]
    by_year["Cumulative"] = by_year["Net"].cumsum()
    payback_year = next((int(y) for y, v in by_year["Cumulative"].items() if v >= 0), None)

    figs = []

    # 1) Year-on-Year stacked cost (CAPEX/OPEX) vs benefit (Recurring/One-Off)
    yr = (cb.groupby("Year")[["CAPEX","OPEX","Benefit Recurring","Benefit One-Off"]]
            .sum().reset_index())
    f1 = go.Figure()
    f1.add_bar(name="CAPEX", x=yr["Year"], y=-yr["CAPEX"], marker_color="#ef4444")
    f1.add_bar(name="OPEX",  x=yr["Year"], y=-yr["OPEX"],  marker_color="#f59e0b")
    f1.add_bar(name="Benefit · Recurring", x=yr["Year"], y=yr["Benefit Recurring"], marker_color="#22c55e")
    f1.add_bar(name="Benefit · One-Off",   x=yr["Year"], y=yr["Benefit One-Off"],   marker_color="#3b82f6")
    f1.update_layout(title="Year-on-Year Cost (CAPEX/OPEX) vs Benefit (Recurring/One-Off)",
                     barmode="relative", **DARK_LAYOUT, height=380,
                     legend=dict(orientation="h", y=-0.2))
    figs.append(("YoY Cost vs Benefit", f1))

    # 2) Cumulative cost vs cumulative benefit (payback curve)
    cum = by_year.reset_index().copy()
    cum["Cum Cost"]    = cum["Total Cost"].cumsum()
    cum["Cum Benefit"] = cum["Total Benefit"].cumsum()
    f2 = go.Figure()
    f2.add_scatter(x=cum["Year"], y=cum["Cum Cost"]/1e6, mode="lines+markers",
                   name="Cumulative Cost ($M)", line=dict(color="#ef4444", width=3))
    f2.add_scatter(x=cum["Year"], y=cum["Cum Benefit"]/1e6, mode="lines+markers",
                   name="Cumulative Benefit ($M)", line=dict(color="#22c55e", width=3))
    f2.add_scatter(x=cum["Year"], y=cum["Cumulative"]/1e6, mode="lines+markers",
                   name="Net Cumulative ($M)",
                   line=dict(color="#3b82f6", width=2, dash="dash"))
    f2.update_layout(title="Cumulative Cost vs Benefit (Payback Curve)",
                     **DARK_LAYOUT, height=380,
                     legend=dict(orientation="h", y=-0.2))
    figs.append(("Cumulative Payback", f2))

    # 3) Per-project bubble — Cost vs Benefit, sized by ROI %
    per = (cb.groupby(["Project ID","Project Name","Program","Benefit Type",
                       "Benefit Category"])[["Total Cost","Total Benefit"]]
             .sum().reset_index())
    per["Net"]   = per["Total Benefit"] - per["Total Cost"]
    per["ROI %"] = np.where(per["Total Cost"]>0,
                            per["Net"]/per["Total Cost"]*100, 0)
    f3 = px.scatter(per, x="Total Cost", y="Total Benefit",
                    size=per["ROI %"].abs().clip(lower=5),
                    color="Benefit Type",
                    hover_data=["Project Name","Program","Benefit Category","ROI %"],
                    color_discrete_map={"Recurring":"#22c55e","One-Off":"#3b82f6"})
    # Add break-even diagonal
    lim = max(per["Total Cost"].max(), per["Total Benefit"].max()) * 1.05
    f3.add_shape(type="line", x0=0, y0=0, x1=lim, y1=lim,
                 line=dict(color="#94a3b8", dash="dash"))
    f3.add_annotation(x=lim*0.7, y=lim*0.72, text="Break-even",
                      showarrow=False, font=dict(color="#94a3b8", size=10))
    f3.update_layout(title="Project Cost vs Benefit (bubble = |ROI %|)",
                     **DARK_LAYOUT, height=480)
    figs.append(("Project Bubble", f3))

    # 4) Top-10 ROI ranking
    top = per.sort_values("ROI %", ascending=True).tail(10)
    f4 = px.bar(top, x="ROI %", y="Project Name", orientation="h",
                color="ROI %", color_continuous_scale="RdYlGn",
                text=top["ROI %"].round(0).astype(int).astype(str)+"%")
    f4.update_layout(title="Top-10 Projects by ROI %", **DARK_LAYOUT, height=400)
    figs.append(("Top ROI", f4))

    # 5) Benefit category mix
    cat = cb.groupby("Benefit Category")["Total Benefit"].sum().reset_index()
    f5 = px.pie(cat, names="Benefit Category", values="Total Benefit", hole=.55,
                color_discrete_sequence=["#3b82f6","#22c55e","#f59e0b","#8b5cf6","#06b6d4"])
    f5.update_layout(title="Benefit Mix by Category", **DARK_LAYOUT, height=360)
    figs.append(("Benefit Mix", f5))

    # 6) Heatmap: Project × Year net benefit
    pivot = cb.pivot_table(index="Project Name", columns="Year",
                           values="Net Benefit", aggfunc="sum", fill_value=0)
    pivot = pivot.loc[pivot.sum(axis=1).sort_values(ascending=False).index].head(20)
    f6 = px.imshow(pivot, color_continuous_scale="RdYlGn", aspect="auto",
                   labels=dict(color="Net Benefit ($)"))
    f6.update_layout(title="Net Benefit Heatmap (Top 20 projects × Year)",
                     **DARK_LAYOUT, height=520)
    figs.append(("Net Benefit Heatmap", f6))

    return {
        "title": "11 · Cost vs Benefit",
        "subtitle": "5-year CAPEX/OPEX vs recurring & one-off benefits",
        "kpis": [
            ("Total Cost",     f"${tot_cost/1e6:.1f}M"),
            ("Total Benefit",  f"${tot_ben/1e6:.1f}M"),
            ("Net Benefit",    f"${net/1e6:.1f}M"),
            ("Portfolio ROI",  f"{roi:.0f}%"),
            ("Benefit-Cost",   f"{bcr:.2f}x"),
            ("Payback Year",   payback_year if payback_year else "—"),
        ],
        "figs": figs,
        "tables": [("Per-Project Summary",
                    per.sort_values("ROI %", ascending=False)
                       .round({"Total Cost":0,"Total Benefit":0,"Net":0,"ROI %":1}))],
    }


BUILDERS = [
    ("executive",    build_executive),
    ("roadmap",      build_roadmap),
    ("projects",     build_projects),
    ("risks",        build_risks),
    ("financials",   build_financials),
    ("governance",   build_governance),
    ("resources",    build_resources),
    ("analytics",    build_analytics),
    ("dependencies", build_dependencies),
    ("pipeline",     build_pipeline),
    ("costbenefit",  build_costbenefit),
]
